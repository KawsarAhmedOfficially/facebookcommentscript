<?php
$data = array
(
    array("iPhone 6s", "iphone-6s.png"),
    array("iPhone 7s", "iphone-7.png"),
    array("One Plus 5", "one-plus-5.jpeg"),
    array("Redmi Note 4", "redmi-note-4.png"),
    array("Redmi 4", "redmi-4.jpeg"),
    array("Google Pixel", "google-pixel.jpg"),
    array("Moto G5 Plus", "moto-g5-plus.jpg")
);
$random = rand(0,6);
$phone_name = $data[$random][0];
$aff_url = "https://www.amazon.in/gp/search?ie=UTF8&tag=mynextphone-21&keywords=".$phone_name;
?>

<html>
<head>
<title>Your Next Phone is: <?php echo $data[$random][0];?></title>
<meta property="og:description" content="Wondering what will be your next phone? Let's have some fun here."/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700"/>
<style type="text/css">
body{
    font-family:'Poppins';
    background-color:#232f3e;
    color:#fff;
}

div{
    text-align:center;
    padding:5px;
    width:100%;
}

.phone-img{
    background-color:#fff;
    padding:20px;
    border:1px solid #000;
    border-radius:5px;
}

.btn{
    padding:10px 30px;
    border-radius:5px;
    border:2px solid #000;
}

a.btn{
    text-decoration:none;
    color:#fff;
}

.btn-name{
    background:#000;
}

.btn-aff{
    background-color:orange;
}

</style>
</head>
<body>
<div class="header">
<h1>Your Next Phone Will be</h1>
<a href="<?php echo $aff_url;?>" class="btn btn-name"><?php echo $phone_name;?></a>
</div>

<div>
  <!-- Ad code here -->
</div>

<div><img class="phone-img" src="img/<?php echo $data[$random][1]; ?>" width="300" height="300"/></div>

<div>
<!-- Ad code here -->
</div>

<div><a href="<?php echo $aff_url;?>" class="btn btn-aff">Know More!</a></div>
</body>
</html>